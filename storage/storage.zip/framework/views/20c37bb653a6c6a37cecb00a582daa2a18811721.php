

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="row justify-content-center mt-5">
    <div class="col-lg-12  sidebar-widgets ">
        <div class="widget-wrap">
            <div class="single-sidebar-widget popular-post-widget">
                <h4 class="popular-title">Edit Channel</h4>
            </div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('channel.edit-channel', ['channel' => $channel])->html();
} elseif ($_instance->childHasBeenRendered('ao6utS9')) {
    $componentId = $_instance->getRenderedChildComponentId('ao6utS9');
    $componentTag = $_instance->getRenderedChildComponentTagName('ao6utS9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ao6utS9');
} else {
    $response = \Livewire\Livewire::mount('channel.edit-channel', ['channel' => $channel]);
    $html = $response->html();
    $_instance->logRenderedChild('ao6utS9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
    </div>
</div>
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/channel/edit.blade.php ENDPATH**/ ?>