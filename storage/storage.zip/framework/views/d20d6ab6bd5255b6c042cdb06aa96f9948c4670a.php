

<?php $__env->startSection('content'); ?>


<!-- start banner Area -->
			<section class="banner-area relative about-banner" id="home">	
				<div class=""></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								<?php echo e($channel->name); ?>	
							</h1>	
							<p class="text-white link-nav"><a href="index.html">Descriptions </a>  <span class="lnr lnr-arrow-right"></span>  <a href="courses.html"> <?php echo e($channel->description); ?></a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

<div class="container mt-3">
    <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <img src="<?php echo e($channel->images_url); ?>" class="rounded-circle mr-3" height="100px;">
            <div>
                <h3 class="pt-3"><?php echo e($channel->name); ?></h3>
                <p class="pt-2"><?php echo e($channel->subscribers()); ?> Subscribers</p>
            </div>
        </div>
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $channel)): ?>
            <a href="<?php echo e(route('channel.edit', $channel)); ?>" class="genric-btn info">Edit Channel</a>
            <?php endif; ?>
        </div>
    </div>
    <div>
        

        <div class="row my-5 ">
            <?php $__currentLoopData = $channel->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-popular-carusel col-lg-3 col-md-6">
                <div class="thumb-wrap relative">
                    <div class="thumb relative rounded">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="<?php echo e(asset( $video->thumbnail)); ?>" alt="">
                    </div>
                    <div class="meta d-flex justify-content-between">
                        <p><span class="lnr lnr-users"></span> <?php echo e($video->views); ?> <span
                                class="lnr lnr-bubble"></span><?php echo e($video->AllcommntsCount()); ?></p>
                        <p class="px-2 rounded " style="background-color: rgb(74, 77, 77);"><?php echo e($video->duration); ?></p>
                    </div>
                </div>
                <div class="details">
                    <a href="<?php echo e(route('video.watch', $video)); ?>">

                        <h4 class="mb-0">
                            <img class="rounded-circle" src="<?php echo e($video->channel->images_url); ?>" alt=""
                                style="height: 40px; margin-right: 10px;">
                            <?php echo e($video->title); ?>

                        </h4>
                    </a>
                    <small>
                        <?php echo e($video->channel->name); ?> Desa : <?php echo e($video->village_name); ?> <br>

                        <?php echo e($video->views); ?> Views . <?php echo e($video->uploaded_date); ?>

                    </small>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/channel/index.blade.php ENDPATH**/ ?>