<?php $__env->startSection('content'); ?>


    

    

    
    





<!-- Start popular-courses Area -->
<section class="popular-courses-area section-gap courses-page">
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="menu-content pb-70 col-lg-8">
                <div class="title text-center">
                    <h1 class="mb-10">Subcriptions</h1>
                    <p>There is a moment in the life of any aspiring.</p>
        <div class="row d-flex justify-content-center text-center">
            <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channelVideos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $__currentLoopData = $channelVideos->unique('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="col-2" style="margin-right: 0%; max-width: 10.66667%; padding-left: 0%; padding-right: 0%;">
                             <a href="<?php echo e(route('channel.index', ['channel' => $video->channel])); ?>" class="text-center">
                               <img class="rounded-circle" src="<?php echo e($video->channel->images_url); ?>" alt="" style="height: 40px;">
                                    
                                     <p class="text-muted" style="font-size:10px;"><?php echo e($video->channel->name); ?> </p> 
                                 </a>
                        </div>
                       
                   

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
                   
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channelVideos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $channelVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="single-popular-carusel col-lg-3 col-md-6">
                <div class="thumb-wrap relative">
                    <div class="thumb relative rounded">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="<?php echo e(asset( $video->thumbnail)); ?>" alt="">
                    </div>
                  
                    <div class="meta d-flex justify-content-between">
                        <p><span class="lnr lnr-users"></span> <?php echo e($video->views); ?> <span
                                class="lnr lnr-bubble"></span><?php echo e($video->AllcommntsCount()); ?></p>
                        <p class="px-2 rounded " style="background-color: rgb(74, 77, 77);"><?php echo e($video->duration); ?></p>
                    </div>
                </div>
                <div class="details">
                    <a href="<?php echo e(route('video.watch', $video)); ?>">

                        <h4 class="mb-0">
                            <img class="rounded-circle" src="<?php echo e($video->channel->images_url); ?>" alt=""
                                style="height: 40px; margin-right: 10px;">
                            <?php echo e($video->title); ?>

                        </h4>
                    </a>
                    <small>
                        <?php echo e($video->channel->name); ?>  <br>
                        Desa : <?php echo e($video->village_name); ?>

                        <br>
                             <?php
                            $n =  $video->views ;
                                if ($n >= 0 && $n < 1000) {
                                    // 1 - 999
                                    $n_format = floor($n);
                                    $suffix = '';
                                } else if ($n >= 1000 && $n < 1000000) {
                                    // 1k-999k
                                    $n_format = floor($n / 1000);
                                    $suffix = 'K+';
                                } else if ($n >= 1000000 && $n < 1000000000) {
                                    // 1m-999m
                                    $n_format = floor($n / 1000000);
                                    $suffix = 'M+';
                                } else if ($n >= 1000000000 && $n < 1000000000000) {
                                    // 1b-999b
                                    $n_format = floor($n / 1000000000);
                                    $suffix = 'B+';
                                } else if ($n >= 1000000000000) {
                                    // 1t+
                                    $n_format = floor($n / 1000000000000);
                                    $suffix = 'T+';
                                }

	                                $cinta = !empty($n_format . $suffix) ? $n_format . $suffix : 0;
                            ?>
                        <?php echo e($cinta); ?> Views . <?php echo e($video->uploaded_date); ?> 
                    </small>

                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



        <div class="row d-flex justify-content-center">
            
        </div>

    </div>
</section>
<!-- End popular-courses Area -->



<!-- Start cta-two Area -->
<section class="cta-two-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 cta-left">
                <h1>Buruan bikin desamu Terkenal ?</h1>
            </div>
            <div class="col-lg-4 cta-right">
                <a class="primary-btn wh" href="#">Join Desatube</a>
            </div>
        </div>
    </div>
</section>
<!-- End cta-two Area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/subscription.blade.php ENDPATH**/ ?>