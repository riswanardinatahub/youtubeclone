<div>
   <?php echo $__env->make('includes.recursive', ['comments' => $video->comments()->LatestFisrt()->get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\desatube\resources\views/livewire/comment/all-comments.blade.php ENDPATH**/ ?>