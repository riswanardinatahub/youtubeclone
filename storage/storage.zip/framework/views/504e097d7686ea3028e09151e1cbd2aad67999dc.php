<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="media my-3" x-data="{open:false, openReply:false}">
    <img class="mr-3 img-fluid img-thumbnail rounded-circle" style="width: 80px;"
        src="<?php echo e($comment->user->channel->images_url); ?>">
    <div class="media-body">
        <h5 class="mt-0"><?php echo e($comment->user->name); ?>

            <small class="text-muted"> <?php echo e($comment->created_at->diffForHumans()); ?> </small>
        </h5>
        <?php echo e($comment->body); ?>

       
        

        <p class="mt-3">
            <a href="" class="text-muted" @click.prevent="openReply = !openReply">REPLY</a>
        </p>
        <?php if(auth()->guard()->check()): ?>
        <div class="my-2" x-show="openReply">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment.new-comment', ['video' => $video,'col' => $comment->id])->html();
} elseif ($_instance->childHasBeenRendered($comment->id . uniqid())) {
    $componentId = $_instance->getRenderedChildComponentId($comment->id . uniqid());
    $componentTag = $_instance->getRenderedChildComponentTagName($comment->id . uniqid());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($comment->id . uniqid());
} else {
    $response = \Livewire\Livewire::mount('comment.new-comment', ['video' => $video,'col' => $comment->id]);
    $html = $response->html();
    $_instance->logRenderedChild($comment->id . uniqid(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php endif; ?>
        <?php if($comment->replies->count()): ?>
        <a href="" @click.prevent="open = !open">view <?php echo e($comment->replies->count()); ?> replies</a>
        <div x-show="open">
            <?php echo $__env->make('includes.recursive', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/includes/recursive.blade.php ENDPATH**/ ?>