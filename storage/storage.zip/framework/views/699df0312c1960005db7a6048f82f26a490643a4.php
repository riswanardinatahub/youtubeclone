<div>
    <div class="d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <img src="<?php echo e($channel->images_url); ?>" class="img-thumbnail rounded-circle" height="90px" width="90px" alt="">

            <div class="ml-2">
                <h4><?php echo e($channel->name); ?></h4>
                <p class="gray-text text-sm"> <?php echo e($channel->subscribers()); ?> Subscribers</p>
            </div>
        </div>
        <div class="">
            <button wire:click.prevent="toggle"
                class="btn btn-lg text-uppercase <?php echo e($userSubscribed ? 'genric-btn danger radius' : 'genric-btn success radius'); ?> ">
                <?php echo e($userSubscribed ? 'Unsubscrribe' : 'Subscribe'); ?>

            </button>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\desatube\resources\views/livewire/channel/channel-info.blade.php ENDPATH**/ ?>