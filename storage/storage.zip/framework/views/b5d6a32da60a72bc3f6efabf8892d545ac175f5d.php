<?php $__env->startSection('content'); ?>


<div class="whole-wrap mt-2">
		<div class="container mt-5">
			<div class="section-top-border">
				<div class="container">
     <div class="row justify-content-center">
        <div class="col-md-8" id="locations">
            <div class="card">
                <div class=" text-center mt-5"><h3> Edit Profile </h3></div>

                <div class="card-body">
                    <form method="POST" action="/profileupdate/<?php echo e($data->id); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($data->name); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($data->email); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                     
                    
                        <div class="form-group row">
                            <label for="provinces_id" class="col-md-4 col-form-label text-md-right">Provinsi</label>
                            <div class="col-md-6">
                            <select name="provinces_id" id="provinces_id" class="form-control" v-if="provinces" v-model="provinces_id">
                            <option v-for="province in provinces" :value="province.id">{{ province.name }}</option>
                            </select>
                            <select v-else class="form-control"></select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="regencies_id" class="col-md-4 col-form-label text-md-right">Kabupaten</label>
                            <div class="col-md-6">
                            <select name="regencies_id" id="regencies_id" class="form-control" v-if="regencies"
                            v-model="regencies_id">
                            <option v-for="regency in regencies" :value="regency.id">{{ regency.name }}</option>
                            </select>
                            <select v-else class="form-control"></select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="districts_id" class="col-md-4 col-form-label text-md-right">Kecamatan/Kelurahan</label>
                            <div class="col-md-6">
                            <select name="districts_id" id="districts_id" class="form-control" v-if="districts"
                            v-model="districts_id">
                            <option v-for="district in districts" :value="district.id">{{ district.name }}</option>
                            </select>
                            <select v-else class="form-control"></select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="villages_id" class="col-md-4 col-form-label text-md-right">Desa</label>
                            <div class="col-md-6">
                            <select name="villages_id" id="villages_id" class="form-control" v-if="villages"
                            v-model="villages_id">
                            <option v-for="village in villages" :value="village.id">{{ village.name }}</option>
                            </select>
                            <select v-else class="form-control"></select>
                            </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="primary-btn text-uppercase">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="/vendor/vue/vue.js"></script>
  <script src="https://unpkg.com/vue-toasted"></script>
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>

 <script>
  var locations = new Vue({
    el: "#locations",
    mounted() {
      AOS.init();
      this.getProvincesData();
      this.getRegenciesData();
      this.getDistrictsData();
      this.getVillagesData();
     
    },
    data: {
      provinces: null,
      regencies: null,
      districts: null,
      villages: null,
      provinces_id: <?php echo e($data->provinces_id); ?>,
      regencies_id: <?php echo e($data->regencies_id); ?>,
      districts_id: <?php echo e($data->districts_id); ?>,
      villages_id: <?php echo e($data->villages_id); ?>,
    },
    methods: {
      getProvincesData() {
        var self = this;
        axios.get('<?php echo e(route('api-provinces')); ?>')
          .then(function (response) {
            self.provinces = response.data;
          })
      },

      getRegenciesData() {
        var self = this;
        axios.get('<?php echo e(url('api/regencies')); ?>/' + self.provinces_id)
          .then(function (response) {
            self.regencies = response.data;
          })
      },

      getDistrictsData() {
        var self = this;
        axios.get('<?php echo e(url('api/districts')); ?>/' + self.regencies_id)
          .then(function (response) {
            self.districts = response.data;
          })
      },

      getVillagesData() {
        var self = this;
        axios.get('<?php echo e(url('api/villages')); ?>/' + self.districts_id)
          .then(function (response) {
            self.villages = response.data;
          })
      },

    },
    watch: {
      provinces_id: function (val, oldVal) {
        this.regencies_id = regencies_id;
        this.getRegenciesData();
      },

      regencies_id: function (val, oldVal) {
        this.districts_id = districts_id;
        this.getDistrictsData();
      },

      districts_id: function (val, oldVal) {
        this.villages_id = villages_id;
        this.getVillagesData();
      }
    }
  });

</script>
 
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/profile.blade.php ENDPATH**/ ?>