

<?php $__env->startSection('content'); ?>



<!-- Start popular-courses Area -->
<section class="popular-courses-area section-gap courses-page">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="menu-content pb-70 col-lg-8">
                <div class="title text-center">
                    <h1 class="mb-10">Desatube</h1>
                    <p>Jadikan desamu lebih mernarik lagi </p>
                    <div class="widget-wrap border-0 p-0" style="background-color: white;">
                        <div class="single-sidebar-widget search-widget">
                            <form class="search-form" action="/search" method="GET">
                                <input placeholder="Search By Desa" name="query" id="query" type="text" required
                                    onfocus="this.placeholder = ''" onblur="this.placeholder = 'Search By Desa'">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-popular-carusel col-lg-3 col-md-6">
                <div class="thumb-wrap relative">
                    <div class="thumb relative rounded">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="<?php echo e(asset( $video->thumbnail)); ?>" alt="">
                    </div>
                    <div class="meta d-flex justify-content-between">
                        <p><span class="lnr lnr-users"></span> <?php echo e($video->views); ?> <span
                                class="lnr lnr-bubble"></span><?php echo e($video->AllcommntsCount()); ?></p>
                        <p class="px-2 rounded " style="background-color: rgb(74, 77, 77);"><?php echo e($video->duration); ?></p>
                    </div>
                </div>
                <div class="details">
                    <a href="<?php echo e(route('video.watch', $video)); ?>">

                        <h4 class="mb-0">
                            <img class="rounded-circle" src="<?php echo e($video->channel->images_url); ?>" alt=""
                                style="height: 40px; margin-right: 10px;">
                            <?php echo e($video->title); ?>

                        </h4>
                    </a>
                    <small>
                        <?php echo e($video->channel->name); ?> Desa : <?php echo e($video->village_name); ?> <br>

                        <?php echo e($video->views); ?> Views . <?php echo e($video->uploaded_date); ?>

                    </small>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



        <div class="row d-flex justify-content-center">
            
        </div>

    </div>
</section>
<!-- End popular-courses Area -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/search.blade.php ENDPATH**/ ?>