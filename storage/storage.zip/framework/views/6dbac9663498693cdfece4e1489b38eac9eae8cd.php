<?php $__env->startSection('content'); ?>



<!-- Start search-course Area -->
	<section class="search-course-area relative ">
		<div class="overlay overlay-bg"></div>
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-4 col-md-6 search-course-right section-gap">
					<form class="form-wrap" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
						<h4 class="text-white pb-20 text-center mb-30">Login Page</h4>
						<input type="email" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Your Email"
							onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'">
                             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"  placeholder="Your Password" required autocomplete="current-password"
							onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Password'">
						
						<button type="submit" class="primary-btn text-uppercase">Submit</button>
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- End search-course Area -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desatube\resources\views/auth/login.blade.php ENDPATH**/ ?>