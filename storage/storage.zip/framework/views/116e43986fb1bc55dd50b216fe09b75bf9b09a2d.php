

            <div class="col-lg-12 sidebar-widgets mt-5">
					<div class="widget-wrap">
						<div class="single-sidebar-widget popular-post-widget">
							<h4 class="popular-title">Your Videos</h4>
            <div class="col-md-12">

                <?php if($videos->count()): ?>
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card my-2">
                    <div class="card-body">
                        <div class="row justify-content-between align-items-center">
                            <div class="col-md-2">
                                <a href="<?php echo e(route('video.watch', $video)); ?>">
                                    <img src="<?php echo e($video->thumbnail); ?>"
                                        class="img-fluid"
                                        alt="">
                                </a>
                            </div>
                            <div class="col-md-2">
                                <h5> <?php echo e($video->title); ?> </h5>
                                <p class="text-truncate"><?php echo e($video->description); ?> </p>
                            </div>
                            <div class="col-md-2">
                                <?php echo e($video->visibility); ?>

                            </div>
                            <div class="col-md-2">
                                <?php echo e($video->created_at->format('d/m/Y')); ?>

                            </div>
                            <?php if(auth()->user()->owns($video)): ?>
                            <div class="col-md-2 p-0">
                                <a href="<?php echo e(route('video.edit', ['channel'=> auth()->user()->channel, 'video' => $video->uid])); ?>"
                                    class="genric-btn info"> Edit</a>
                                    

                                    <button type="button" wire:click="deleteId(<?php echo e($video->id); ?>)" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">Delete</button>
                                
                            </div>
                           

                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <h1> No Videos </h1>

                <?php endif; ?>

<!-- Modal -->
            <div wire:ignore.self class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Delete Confirm</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true close-btn">×</span>
                            </button>
                        </div>
                       <div class="modal-body">
                            <p>Are you sure want to delete?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary close-btn" data-dismiss="modal">Close</button>
                            <button type="button" wire:click.prevent="delete()" class="btn btn-danger close-modal" data-dismiss="modal">Yes, Delete</button>
                        </div>
                    </div>
                </div>
            </div>

            </div>

            <nav class="blog-pagination justify-content-center d-flex">
						<ul class="pagination">
							<?php echo e($videos->links()); ?>

						</ul>
					</nav>

							
						</div>
						
					</div>
			</div><?php /**PATH C:\laragon\www\desatube\resources\views/livewire/video/all-video.blade.php ENDPATH**/ ?>