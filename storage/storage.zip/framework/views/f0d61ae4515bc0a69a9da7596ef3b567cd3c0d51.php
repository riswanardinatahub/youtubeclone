
 

 <div class="row justify-content-center mt-5">
<div class="col-lg-6  sidebar-widgets ">
    <div class="widget-wrap">
        <div class="single-sidebar-widget popular-post-widget">
            <h4 class="popular-title">Edit Video</h4>
        </div>
        <div <?php if($video->processing_percentage < 100): ?> wire:poll <?php endif; ?>>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-4">
                        <img src="<?php echo e(asset($this->video->thumbnail)); ?>" class="img-thumbnail" alt="">
                    </div>

                    <div class="col-md-4">
                        <p> Processing (<?php echo e($this->video->processing_percentage); ?>) %</p>
                    </div>
                </div>

                <form wire:submit.prevent="update">

                    <div class="form-group">
                        <label for="title"> title</label>
                        <input type="text" class="form-control" wire:model="video.title">
                    </div>
                    <?php $__errorArgs = ['video.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea cols="30" rows="4" class="form-control" wire:model="video.description"> </textarea>
                    </div>

                    <?php $__errorArgs = ['video.description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <div class="form-group">
                        <label for="visibility">visibility</label>
                        <select wire:model="video.visibility" class="form-control">
                            <option value="private">private</option>
                            <option value="public">public</option>
                        </select>
                    </div>

                    <?php $__errorArgs = ['video.description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group">
                        <button type="submit" class="genric-btn success radius">Update</button>
                    </div>

                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                    <?php endif; ?>
                </form>

            </div>
        </div>
    </div>
</div>
    </div>
</div>

 </div>

<?php /**PATH C:\laragon\www\desatube\resources\views/livewire/video/edit-video.blade.php ENDPATH**/ ?>